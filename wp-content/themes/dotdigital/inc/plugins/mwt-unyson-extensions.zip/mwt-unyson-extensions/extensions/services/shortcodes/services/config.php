<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array(
	'page_builder' => array(
		'title'       => esc_html__( 'Services', 'fw' ),
		'description' => esc_html__( 'Services various views', 'fw' ),
		'tab'         => esc_html__( 'Widgets', 'fw' )
	)
);