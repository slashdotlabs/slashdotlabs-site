<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['icon-set'] = 'rt-icons-2';
$cfg['has-icon'] = true;