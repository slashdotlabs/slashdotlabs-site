<?php

include( fw()->extensions->get( 'services' )->locate_view_path( 'archive' ) );