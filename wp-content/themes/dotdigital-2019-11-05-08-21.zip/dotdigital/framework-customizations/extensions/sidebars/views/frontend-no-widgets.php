<?php if (!defined('FW')) die('Forbidden');

esc_html_e('1', 'dotdigital');