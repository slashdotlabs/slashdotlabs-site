<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg['page_builder'] = array(
	'title'       => esc_html__( 'Social Icons', 'dotdigital' ),
	'description' => esc_html__( 'Add set of social icons', 'dotdigital' ),
	'tab'         => esc_html__( 'Content Elements', 'dotdigital' )
);