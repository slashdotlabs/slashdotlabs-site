<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

//$cfg = array();

$cfg['page_builder'] = array(
	'title'       => esc_html__( 'Pie Chart', 'dotdigital' ),
	'description' => esc_html__( 'Add a Pie Chart', 'dotdigital' ),
	'tab'         => esc_html__( 'Content Elements', 'dotdigital' )
);