<?php if (!defined('FW')) die('Forbidden');

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => esc_html__('Video', 'dotdigital'),
	'description'   => esc_html__('Add a Video', 'dotdigital'),
	'tab'           => esc_html__('Media Elements', 'dotdigital'),
);
