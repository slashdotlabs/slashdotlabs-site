<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg['page_builder'] = array(
	'title'       => esc_html__( 'Progress Bar', 'dotdigital' ),
	'description' => esc_html__( 'Add a Bootsrap progress bar', 'dotdigital' ),
	'tab'         => esc_html__( 'Content Elements', 'dotdigital' )
);