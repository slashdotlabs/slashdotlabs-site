<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}
$manifest['standalone'] = true;