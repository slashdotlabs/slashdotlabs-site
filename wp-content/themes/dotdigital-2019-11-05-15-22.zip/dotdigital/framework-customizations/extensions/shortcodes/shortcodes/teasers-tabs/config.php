<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array(
	'page_builder' => array(
		'title'       => esc_html__( 'Teasers in Tabs', 'dotdigital' ),
		'description' => esc_html__( 'Show Bootstrap tabs with teasers', 'dotdigital' ),
		'tab'         => esc_html__( 'Content Elements', 'dotdigital' ),
	)
);