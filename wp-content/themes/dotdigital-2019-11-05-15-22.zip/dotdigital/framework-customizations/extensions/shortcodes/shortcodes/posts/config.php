<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array(
	'page_builder' => array(
		'title'       => esc_html__( 'Posts', 'dotdigital' ),
		'description' => esc_html__( 'Posts various views', 'dotdigital' ),
		'tab'         => esc_html__( 'Widgets', 'dotdigital' )
	)
);