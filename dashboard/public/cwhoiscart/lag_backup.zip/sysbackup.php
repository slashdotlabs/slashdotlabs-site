<?
system ("zip -r lag_backup.zip *")
?>